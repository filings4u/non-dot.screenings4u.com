import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE =
  Deno.env.get("SUPABASE_SECRET_KEY") ||
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ||
  "";
const STRIPE_SECRET =
  Deno.env.get("STRIPE_SECRET_KEY") ||
  Deno.env.get("STRIPE_API_KEY") ||
  "";

const db = createClient(SUPABASE_URL, SERVICE_ROLE, {
  auth: { persistSession: false, autoRefreshToken: false }
});

const H = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

const J = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: H });

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PLAN = /^workforce_(employer|ctpa)_(essential|professional|enterprise)$/;

function clean(value: unknown, max = 300) {
  return String(value ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .trim()
    .slice(0, max);
}

function tracking(id: string) {
  return "S4U-W-" +
    String(id || "")
      .replace(/-/g, "")
      .slice(0, 10)
      .toUpperCase()
      .padEnd(10, "0");
}

async function stripePost(path: string, form: URLSearchParams) {
  const response = await fetch("https://api.stripe.com/v1/" + path, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + STRIPE_SECRET,
      "Content-Type": "application/x-www-form-urlencoded",
      "Stripe-Version": "2026-07-29.dahlia"
    },
    body: form.toString()
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      data?.error?.message ||
      data?.message ||
      ("Stripe request failed (" + response.status + ").")
    );
  }

  return data;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: H });
  }

  if (request.method !== "POST") {
    return J({ error: "Method not allowed." }, 405);
  }

  let intentId: string | null = null;

  try {
    if (!STRIPE_SECRET) {
      return J({ error: "Stripe is not configured." }, 503);
    }

    const body = await request.json().catch(() => ({}));
    const serviceId = clean(body?.serviceId, 120).toLowerCase();

    if (!PLAN.test(serviceId)) {
      return J({ error: "A valid Workforce subscription plan is required." }, 400);
    }

    if (body?.discountCode) {
      return J({
        error: "Discount codes are not available for Workforce subscription plans."
      }, 400);
    }

    const customerInput = body?.customer || {};
    const firstName = clean(customerInput.firstName, 100);
    const lastName = clean(customerInput.lastName, 100);
    const email = clean(customerInput.email, 320).toLowerCase();
    const phone = clean(customerInput.phone, 60);
    const address = clean(customerInput.address, 200);
    const address2 = clean(customerInput.address2, 100);
    const city = clean(customerInput.city, 120);
    const state = clean(customerInput.state, 20).toUpperCase();
    const zip = clean(customerInput.zip, 20);

    if (!firstName || !lastName || !EMAIL.test(email) || !phone) {
      return J({ error: "First name, last name, email, and phone are required." }, 400);
    }

    if (!address || !city || !state || !zip) {
      return J({ error: "Complete the billing address before continuing." }, 400);
    }

    const pr = await db
      .from("workforce_plans")
      .select("id,code,name,description,audience,monthly_price,active")
      .eq("code", serviceId)
      .eq("active", true)
      .maybeSingle();

    if (pr.error) throw pr.error;
    if (!pr.data) {
      return J({ error: "The selected Workforce plan is unavailable." }, 404);
    }

    const plan: any = pr.data;

    const cfg = await db
      .from("workforce_stripe_plan_config")
      .select("stripe_product_id,stripe_price_id,livemode")
      .eq("plan_id", plan.id)
      .maybeSingle();

    if (cfg.error) throw cfg.error;
    if (!cfg.data?.stripe_price_id) {
      return J({ error: "Stripe pricing is not configured for this plan." }, 503);
    }

    const reference =
      "WF-" +
      new Date().toISOString().slice(0, 10).replaceAll("-", "") +
      "-" +
      crypto.randomUUID().slice(0, 10).toUpperCase();

    const portalCode =
      plan.audience === "ctpa" ? "ctpa_workforce" : "employer_workforce";

    const ir = await db
      .from("workforce_checkout_intents")
      .insert({
        reference,
        plan_id: plan.id,
        account_type: plan.audience,
        first_name: firstName,
        last_name: lastName,
        email,
        phone,
        status: "checkout_started",
        workforce_classification: "NON_DOT",
        intake_required: true,
        metadata: {
          source: "workforce_payment_element_subscription",
          purchase_surface: "workforce.screenings4u.com",
          portal_code: portalCode,
          plan_code: plan.code,
          stripe_price_id: cfg.data.stripe_price_id,
          stripe_product_id: cfg.data.stripe_product_id || null
        }
      })
      .select("id")
      .single();

    if (ir.error) throw ir.error;
    intentId = ir.data.id;

    const customerForm = new URLSearchParams();
    customerForm.set("name", (firstName + " " + lastName).trim());
    customerForm.set("email", email);
    customerForm.set("phone", phone);
    customerForm.set("address[line1]", address);
    if (address2) customerForm.set("address[line2]", address2);
    customerForm.set("address[city]", city);
    customerForm.set("address[state]", state);
    customerForm.set("address[postal_code]", zip);
    customerForm.set("address[country]", "US");
    customerForm.set("metadata[workforce_checkout_intent_id]", intentId);
    customerForm.set("metadata[workforce_reference]", reference);

    const customer = await stripePost("customers", customerForm);

    const subForm = new URLSearchParams();
    subForm.set("customer", String(customer.id));
    subForm.set("items[0][price]", String(cfg.data.stripe_price_id));
    subForm.set("payment_behavior", "default_incomplete");
    subForm.set("payment_settings[save_default_payment_method]", "on_subscription");
    subForm.set("collection_method", "charge_automatically");
    subForm.set("metadata[workforce_type]", "subscription");
    subForm.set("metadata[checkout_intent_id]", intentId);
    subForm.set("metadata[checkout_reference]", reference);
    subForm.set("metadata[plan_id]", String(plan.id));
    subForm.set("metadata[plan_code]", String(plan.code));
    subForm.set("metadata[portal_code]", portalCode);
    subForm.set("metadata[purchase_surface]", "workforce.screenings4u.com");
    subForm.append("expand[]", "latest_invoice.confirmation_secret");

    const subscription = await stripePost("subscriptions", subForm);

    const invoice =
      subscription?.latest_invoice &&
      typeof subscription.latest_invoice === "object"
        ? subscription.latest_invoice
        : null;

    const clientSecret = invoice?.confirmation_secret?.client_secret || null;

    if (!clientSecret) {
      throw new Error(
        "Stripe did not return a payment confirmation secret for this subscription."
      );
    }

    const paymentIntentId =
      typeof clientSecret === "string" && clientSecret.includes("_secret_")
        ? clientSecret.split("_secret_")[0]
        : null;

    const up = await db
      .from("workforce_checkout_intents")
      .update({
        stripe_customer_id: String(customer.id || ""),
        stripe_subscription_id: String(subscription.id || ""),
        metadata: {
          source: "workforce_payment_element_subscription",
          purchase_surface: "workforce.screenings4u.com",
          portal_code: portalCode,
          plan_code: plan.code,
          stripe_price_id: cfg.data.stripe_price_id,
          stripe_product_id: cfg.data.stripe_product_id || null,
          stripe_invoice_id: invoice?.id || null,
          stripe_payment_intent_id: paymentIntentId
        },
        updated_at: new Date().toISOString()
      })
      .eq("id", intentId);

    if (up.error) throw up.error;

    const monthly = Number(plan.monthly_price || 0);

    return J({
      clientSecret,
      paymentIntentId,
      orderId: intentId,
      orderNumber: reference,
      trackingNumber: tracking(intentId),
      serviceId: plan.code,
      serviceName: plan.name,
      serviceType: "workforce_subscription",
      amount: Math.round(monthly * 100),
      currency: "usd",
      subtotal: monthly,
      discountCode: null,
      discountAmount: 0,
      total: monthly,
      accountType: plan.audience,
      billingFrequency: "monthly"
    });
  } catch (error) {
    console.error("create-payment-intent", error);

    if (intentId) {
      try {
        await db
          .from("workforce_checkout_intents")
          .update({
            status: "failed",
            updated_at: new Date().toISOString()
          })
          .eq("id", intentId);
      } catch {}
    }

    return J(
      {
        error:
          error instanceof Error
            ? error.message
            : "Unable to create the Workforce subscription payment."
      },
      500
    );
  }
});
